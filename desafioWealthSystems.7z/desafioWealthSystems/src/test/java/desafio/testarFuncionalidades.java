package desafio;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class testarFuncionalidades {

    public WebDriver chrome;

    @Before
    public void setUp() {
        System.setProperty("webdriver.chrome.driver", "C:\\Temp\\chromedriver.exe");
        chrome = new ChromeDriver();
        chrome.manage().window().maximize();
    }

    @Test
    public void executaTeste() {
        chrome.get("https://the-internet.herokuapp.com/dynamic_loading/1");

        // Aguarda a página carregar
        WebDriverWait wait = new WebDriverWait(chrome, 5);
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//div[@id='start']/button")));

        // Clica no botão Start
        WebElement btnStart = chrome.findElement(By.xpath("//div[@id='start']/button"));
        btnStart.click();

        // Aguarda até que o texto "Hello World" seja exibido
        wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@id='finish']/h4")));

        // Verifica se o texto "Hello World" é exibido
        WebElement texto = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@id='finish']/h4"));
        Assert.assertEquals(texto.getText(), "Hello World!");
        System.out.println("O texto ("+ texto.getText().toString() +") foi exibido com sucesso!");

        // SEGUNDO DESAFIO
        // Abre a página para o próximo desafio
        chrome.get("https://the-internet.herokuapp.com/challenging_dom");

        // Aguarda a página carregar e clica no primeiro botão (o botão azul)
        wait.until(ExpectedConditions.elementToBeClickable(By.className("button")));
        WebElement btnAzul = chrome.findElement(By.className("button"));
        btnAzul.click();

        // Clica no segundo botão (o vermelho)
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@class, 'button alert')]")));
        WebElement btnVermelho = chrome.findElement(By.xpath("//a[contains(@class, 'button alert')]"));
        btnVermelho.click();

        // Clica no terceiro botão (o verde)
        wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//a[contains(@class, 'button success')]")));
        WebElement btnVerde = chrome.findElement(By.xpath("//a[contains(@class, 'button success')]"));
        btnVerde.click();

        // Clica nos botões Edit e Delete do grid
        // Primeira linha
        WebElement btnEdit1 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[1]/td[7]/a[1]"));
        btnEdit1.click();

        WebElement btnDelete1 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[1]/td[7]/a[2]"));
        btnDelete1.click();

        // Segunda linha
        WebElement btnEdit2 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[2]/td[7]/a[1]"));
        btnEdit2.click();

        WebElement btnDelete2 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[2]/td[7]/a[2]"));
        btnDelete2.click();

        // Terceira linha
        WebElement btnEdit3 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[3]/td[7]/a[1]"));
        btnEdit3.click();

        WebElement btnDelete3 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[3]/td[7]/a[2]"));
        btnDelete3.click();

        // Quarta linha
        WebElement btnEdit4 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[4]/td[7]/a[1]"));
        btnEdit4.click();

        WebElement btnDelete4 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[4]/td[7]/a[2]"));
        btnDelete4.click();

        // Quinta linha
        WebElement btnEdit5 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[6]/td[7]/a[1]"));
        btnEdit5.click();

        WebElement btnDelete5 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[6]/td[7]/a[2]"));
        btnDelete5.click();

        //Sexta linha
        WebElement btnEdit6 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[7]/td[7]/a[1]"));
        btnEdit6.click();

        WebElement btnDelete6 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[7]/td[7]/a[2]"));
        btnDelete6.click();

        // Sétima linha
        WebElement btnEdit7 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[8]/td[7]/a[1]"));
        btnEdit7.click();

        WebElement btnDelete7 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[8]/td[7]/a[2]"));
        btnDelete7.click();

        // Oitava linha
        WebElement btnEdit8 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[9]/td[7]/a[1]"));
        btnEdit8.click();

        WebElement btnDelete8 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[9]/td[7]/a[2]"));
        btnDelete8.click();

        // Nona lina
        WebElement btnEdit9 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[10]/td[7]/a[1]"));
        btnEdit9.click();

        WebElement btnDelete9 = chrome.findElement(By.xpath("/html[@class='no-js']/body/div[@class='row'][2]/div[@id='content']/div[@class='example']/div[@class='row']/div[@class='large-12 columns large-centered']/div[@class='large-10 columns']/table/tbody/tr[10]/td[7]/a[2]"));
        btnDelete9.click();

        // Fecha o chrome
        chrome.quit();
    }
}
